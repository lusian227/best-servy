﻿// src/modules/records/repositories/IRepository.ts

export interface IRepository<T, TId> {
  save(entity: T): Promise<T>;
  findById(id: TId): Promise<T | null>;
  findAll(): Promise<T[]>;
  update(id: TId, entity: Partial<T>): Promise<T>;
  delete(id: TId): Promise<void>;
  exists(id: TId): Promise<boolean>;
  count(): Promise<number>;
}
