﻿// src/domain/records/EngineeringRecord.ts

export type RecordCategory =
  | 'drawing'
  | 'specification'
  | 'report'
  | 'photo'
  | 'calculation'
  | 'rfi'
  | 'contract'
  | 'submittal'
  | 'model'
  | 'document'
  | 'spreadsheet'
  | 'presentation'
  | 'research'
  | 'other';

export type Discipline =
  | 'structural'
  | 'architectural'
  | 'mep'
  | 'civil'
  | 'geotechnical'
  | 'environmental'
  | 'fire_protection'
  | 'interior'
  | 'landscape'
  | 'acoustical'
  | 'telecommunications'
  | 'security'
  | 'surveying'
  | 'hydrology'
  | 'transportation'
  | 'other';

export type RecordStatus =
  | 'draft'
  | 'under_review'
  | 'approved'
  | 'issued'
  | 'superseded'
  | 'archived'
  | 'rejected'
  | 'on_hold';

export interface EngineeringRecord {
  id: string;
  workspaceId: string;
  
  // Universal parent - can belong to a Work Item OR directly to Workspace
  parentType: 'workspace' | 'workItem';
  parentId: string;
  
  // Identity
  title: string;
  description?: string;
  recordNumber: string;
  
  // Classification
  category: RecordCategory;
  discipline: Discipline;
  
  // Version
  revision: string;
  version: number;
  isLatest: boolean;
  
  // Status
  status: RecordStatus;
  
  // Files (the actual evidence)
  fileIds: string[];  // References to StoredFile
  primaryFileId?: string;
  
  // Metadata - completely flexible! No hardcoded fields.
  metadata: Record<string, any>;
  
  // Relationships
  relatedRecordIds: string[];
  dependencies: string[];
  tags: string[];
  
  // Tracking
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
}

export const recordCategoryLabels: Record<RecordCategory, string> = {
  drawing: 'Drawing',
  specification: 'Specification',
  report: 'Report',
  photo: 'Photo',
  calculation: 'Calculation',
  rfi: 'RFI',
  contract: 'Contract',
  submittal: 'Submittal',
  model: 'Model',
  document: 'Document',
  spreadsheet: 'Spreadsheet',
  presentation: 'Presentation',
  research: 'Research',
  other: 'Other',
};

export const disciplineLabels: Record<Discipline, string> = {
  structural: 'Structural',
  architectural: 'Architectural',
  mep: 'MEP',
  civil: 'Civil',
  geotechnical: 'Geotechnical',
  environmental: 'Environmental',
  fire_protection: 'Fire Protection',
  interior: 'Interior',
  landscape: 'Landscape',
  acoustical: 'Acoustical',
  telecommunications: 'Telecommunications',
  security: 'Security',
  surveying: 'Surveying',
  hydrology: 'Hydrology',
  transportation: 'Transportation',
  other: 'Other',
};
