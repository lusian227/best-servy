﻿// src/components/projects/DrawingStudio.tsx

import React, { useState } from 'react';
import { X, ZoomIn, ZoomOut, Download, RotateCw, ChevronLeft, ChevronRight } from 'lucide-react';

interface DrawingStudioProps {
  drawings: any[];
  onClose: () => void;
}

export function DrawingStudio({ drawings, onClose }: DrawingStudioProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [zoom, setZoom] = useState(1);

  if (!drawings || drawings.length === 0) {
    return (
      <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center">
        <div className="text-white text-center">
          <p className="text-xl">No drawings to display</p>
          <button onClick={onClose} className="mt-4 px-4 py-2 bg-white/20 rounded-lg hover:bg-white/30 transition">
            Close
          </button>
        </div>
      </div>
    );
  }

  const currentDrawing = drawings[currentIndex];
  
  // Check if the URL is a blob URL that might be expired
  const isBlobUrl = currentDrawing?.metadata?.storageUrl?.startsWith('blob:');
  
  // For blob URLs, try to use a fallback or show a message
  const imageUrl = isBlobUrl 
    ? null // Don't try to display expired blob URLs
    : currentDrawing?.metadata?.storageUrl || currentDrawing?.url;

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : drawings.length - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev < drawings.length - 1 ? prev + 1 : 0));
  };

  const handleDownload = () => {
    if (imageUrl) {
      window.open(imageUrl, '_blank');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-slate-900/50 backdrop-blur-sm border-b border-slate-700">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="p-2 hover:bg-slate-700 rounded-lg transition">
            <X className="w-5 h-5 text-white" />
          </button>
          <div>
            <h3 className="text-white font-medium">{currentDrawing?.title || 'Drawing'}</h3>
            <p className="text-xs text-slate-400">
              {currentIndex + 1} of {drawings.length} • {currentDrawing?.drawingNumber || ''}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoom(Math.min(zoom + 0.25, 3))}
            className="p-2 hover:bg-slate-700 rounded-lg transition text-white"
          >
            <ZoomIn className="w-5 h-5" />
          </button>
          <button
            onClick={() => setZoom(Math.max(zoom - 0.25, 0.5))}
            className="p-2 hover:bg-slate-700 rounded-lg transition text-white"
          >
            <ZoomOut className="w-5 h-5" />
          </button>
          <button
            onClick={handleDownload}
            className="p-2 hover:bg-slate-700 rounded-lg transition text-white"
          >
            <Download className="w-5 h-5" />
          </button>
          <span className="text-xs text-slate-400 ml-2">{Math.round(zoom * 100)}%</span>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center p-4 relative">
        {/* Navigation Buttons */}
        {drawings.length > 1 && (
          <>
            <button
              onClick={handlePrevious}
              className="absolute left-4 top-1/2 -translate-y-1/2 p-3 bg-black/50 hover:bg-black/70 rounded-full transition text-white"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={handleNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-black/50 hover:bg-black/70 rounded-full transition text-white"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </>
        )}

        {/* Image Display */}
        <div className="flex items-center justify-center max-w-full max-h-full">
          {isBlobUrl ? (
            <div className="text-center text-slate-400">
              <div className="text-6xl mb-4">🖼️</div>
              <p className="text-lg">Image preview not available</p>
              <p className="text-sm mt-2">The image was uploaded but the preview URL has expired.</p>
              <button
                onClick={handleDownload}
                className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition"
              >
                Download File
              </button>
            </div>
          ) : imageUrl ? (
            <img
              src={imageUrl}
              alt={currentDrawing?.title || 'Drawing'}
              className="max-w-full max-h-[80vh] object-contain transition-transform duration-200"
              style={{ transform: scale() }}
              onError={(e) => {
                console.error('Image failed to load:', imageUrl);
                (e.target as HTMLImageElement).style.display = 'none';
                // Show fallback
                const parent = (e.target as HTMLImageElement).parentElement;
                if (parent) {
                  const fallback = document.createElement('div');
                  fallback.className = 'text-center text-slate-400';
                  fallback.innerHTML = 
                    <div class="text-6xl mb-4">🖼️</div>
                    <p class="text-lg">Image failed to load</p>
                    <p class="text-sm mt-2">The file may have been moved or deleted.</p>
                  ;
                  parent.appendChild(fallback);
                }
              }}
            />
          ) : (
            <div className="text-center text-slate-400">
              <div className="text-6xl mb-4">📄</div>
              <p className="text-lg">No preview available</p>
              <button
                onClick={handleDownload}
                className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition"
              >
                Download File
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Thumbnails */}
      {drawings.length > 1 && (
        <div className="p-4 bg-slate-900/50 backdrop-blur-sm border-t border-slate-700">
          <div className="flex gap-2 overflow-x-auto justify-center">
            {drawings.map((drawing, index) => (
              <button
                key={drawing.id || index}
                onClick={() => setCurrentIndex(index)}
                className={w-16 h-16 rounded-lg overflow-hidden border-2 transition flex items-center justify-center text-xs text-slate-400 }
              >
                {drawing?.metadata?.storageUrl && !drawing.metadata.storageUrl.startsWith('blob:') ? (
                  <img
                    src={drawing.metadata.storageUrl}
                    alt={drawing.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <span className="text-2xl">📄</span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
