﻿// src/modules/records/components/RecordList.tsx

import React from 'react';
import { RecordLibrary } from './RecordLibrary';

export function RecordList() {
  return <RecordLibrary />;
}
