﻿// src/modules/records/services/__tests__/RecordService.test.ts

import { RecordService } from '../RecordService';
import { RecordCategory, RecordType, Discipline } from '../../domain/EngineeringRecord';

describe('RecordService', () => {
  let service: RecordService;

  beforeEach(() => {
    service = new RecordService();
  });

  test('should create a record', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Test Drawing',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const record = await service.createRecord(input);
    expect(record.id).toBeDefined();
    expect(record.recordNumber).toMatch(/^DRA-/);
    expect(record.title).toBe('Test Drawing');
    expect(record.status).toBe('draft');
  });

  test('should get a record', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Test Record',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const created = await service.createRecord(input);
    const retrieved = await service.getRecord(created.id);
    expect(retrieved).toBeDefined();
    expect(retrieved?.id).toBe(created.id);
  });

  test('should search records', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Search Test',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    await service.createRecord(input);
    const results = await service.search('Search Test');
    expect(results.length).toBeGreaterThan(0);
  });

  test('should update a record', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Original Title',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const created = await service.createRecord(input);
    
    const updated = await service.updateRecord(created.id, {
      title: 'Updated Title',
      updatedBy: 'user-456'
    });

    expect(updated.title).toBe('Updated Title');
    expect(updated.version).toBe(created.version + 1);
  });

  test('should upload a file to a record', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'File Test',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const record = await service.createRecord(input);
    
    const file = new File(['test content'], 'test.pdf', { type: 'application/pdf' });
    const storedFile = await service.uploadFile(record.id, file, 'user-123');

    expect(storedFile.id).toBeDefined();
    expect(storedFile.filename).toBe('test.pdf');
    expect(storedFile.recordId).toBe(record.id);
  });

  test('should create a version', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Version Test',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const record = await service.createRecord(input);
    const version = await service.createVersion(record.id, 'Initial version');

    expect(version.version).toBe(record.version + 1);
    expect(version.changelog).toBe('Initial version');
  });

  test('should submit for approval', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Approval Test',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const record = await service.createRecord(input);
    const approval = await service.submitForApproval(record.id, 'user-123');

    expect(approval.status).toBe('pending');
    expect(record.status).toBe('under_review');
  });

  test('should approve a record', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Approve Test',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const record = await service.createRecord(input);
    await service.submitForApproval(record.id, 'user-123');
    const approval = await service.approve(record.id, 'user-456', 'Looks good!');

    expect(approval.status).toBe('approved');
    expect(record.status).toBe('approved');
  });

  test('should reject a record', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Reject Test',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const record = await service.createRecord(input);
    await service.submitForApproval(record.id, 'user-123');
    const approval = await service.reject(record.id, 'user-456', 'Needs revisions');

    expect(approval.status).toBe('rejected');
    expect(record.status).toBe('rejected');
  });

  test('should add an annotation', async () => {
    const input = {
      projectId: 'proj-123',
      title: 'Annotation Test',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const record = await service.createRecord(input);
    const annotation = await service.addAnnotation(
      record.id,
      {
        type: 'comment',
        content: 'This needs review',
        page: 1,
        position: { x: 100, y: 200 }
      },
      'user-123'
    );

    expect(annotation.id).toBeDefined();
    expect(annotation.content).toBe('This needs review');
    expect(annotation.resolved).toBe(false);
  });

  test('should create a link between records', async () => {
    const input1 = {
      projectId: 'proj-123',
      title: 'Source Record',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const input2 = {
      projectId: 'proj-123',
      title: 'Target Record',
      category: RecordCategory.SPECIFICATION,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      createdBy: 'user-123'
    };

    const source = await service.createRecord(input1);
    const target = await service.createRecord(input2);

    const link = await service.createLink(source.id, target.id, 'reference', 'user-123');

    expect(link.id).toBeDefined();
    expect(link.sourceRecordId).toBe(source.id);
    expect(link.targetRecordId).toBe(target.id);
    expect(link.relation).toBe('reference');
  });
});
