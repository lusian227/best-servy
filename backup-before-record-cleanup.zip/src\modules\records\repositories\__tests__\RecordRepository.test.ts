﻿// src/modules/records/repositories/__tests__/RecordRepository.test.ts

import { RecordRepository } from '../RecordRepository';
import { EngineeringRecord, RecordCategory, RecordType, Discipline, RecordStatus } from '../../domain/EngineeringRecord';

describe('RecordRepository', () => {
  let repository: RecordRepository;

  beforeEach(() => {
    repository = new RecordRepository();
  });

  test('should save and find a record', async () => {
    const record: EngineeringRecord = {
      id: 'test-1',
      projectId: 'proj-1',
      recordNumber: 'TEST-001',
      title: 'Test Record',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      revision: 'REV0',
      version: 1,
      isLatest: true,
      status: RecordStatus.DRAFT,
      workflowState: 'draft',
      files: [],
      primaryFileId: '',
      links: [],
      dependencies: [],
      annotations: [],
      versions: [],
      approval: {} as any,
      audit: {} as any,
      ai: {} as any,
      metadata: { customFields: {} },
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: 'user-1',
      updatedBy: 'user-1'
    };

    await repository.save(record);
    const found = await repository.findById('test-1');
    expect(found).toBeDefined();
    expect(found?.title).toBe('Test Record');
  });

  test('should find records by project', async () => {
    const record1: EngineeringRecord = {
      id: 'test-2',
      projectId: 'proj-1',
      recordNumber: 'TEST-002',
      title: 'Project 1 Record',
      category: RecordCategory.DRAWING,
      type: RecordType.PDF,
      discipline: Discipline.STRUCTURAL,
      revision: 'REV0',
      version: 1,
      isLatest: true,
      status: RecordStatus.DRAFT,
      workflowState: 'draft',
      files: [],
      primaryFileId: '',
      links: [],
      dependencies: [],
      annotations: [],
      versions: [],
      approval: {} as any,
      audit: {} as any,
      ai: {} as any,
      metadata: { customFields: {} },
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: 'user-1',
      updatedBy: 'user-1'
    };

    await repository.save(record1);
    const results = await repository.findByProject('proj-1');
    expect(results.length).toBeGreaterThan(0);
  });
});
