﻿// src/modules/records/repositories/FileRepository.ts

import { StoredFile } from '../domain/StoredFile';
import { IRepository } from './IRepository';

export interface IFileRepository extends IRepository<StoredFile, string> {
  findByRecord(recordId: string): Promise<StoredFile[]>;
  findByVersion(versionId: string): Promise<StoredFile[]>;
  getPrimaryFile(recordId: string): Promise<StoredFile | null>;
}

export class FileRepository implements IFileRepository {
  private files: Map<string, StoredFile> = new Map();

  async save(file: StoredFile): Promise<StoredFile> {
    this.files.set(file.id, file);
    return file;
  }

  async findById(id: string): Promise<StoredFile | null> {
    return this.files.get(id) || null;
  }

  async findAll(): Promise<StoredFile[]> {
    return Array.from(this.files.values());
  }

  async findByRecord(recordId: string): Promise<StoredFile[]> {
    const results: StoredFile[] = [];
    for (const file of this.files.values()) {
      if (file.recordId === recordId) {
        results.push(file);
      }
    }
    return results;
  }

  async findByVersion(versionId: string): Promise<StoredFile[]> {
    const results: StoredFile[] = [];
    for (const file of this.files.values()) {
      if (file.versionId === versionId) {
        results.push(file);
      }
    }
    return results;
  }

  async getPrimaryFile(recordId: string): Promise<StoredFile | null> {
    for (const file of this.files.values()) {
      if (file.recordId === recordId && file.isPrimary) {
        return file;
      }
    }
    return null;
  }

  async update(id: string, entity: Partial<StoredFile>): Promise<StoredFile> {
    const existing = await this.findById(id);
    if (!existing) {
      throw new Error(File with id  not found);
    }
    const updated = { ...existing, ...entity };
    this.files.set(id, updated);
    return updated;
  }

  async delete(id: string): Promise<void> {
    this.files.delete(id);
  }

  async exists(id: string): Promise<boolean> {
    return this.files.has(id);
  }

  async count(): Promise<number> {
    return this.files.size;
  }

  async clear(): Promise<void> {
    this.files.clear();
  }
}
