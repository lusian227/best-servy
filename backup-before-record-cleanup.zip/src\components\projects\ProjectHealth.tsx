import React from 'react';
import { ProjectHealthMetrics } from '../../types';
import { Activity, ShieldCheck, AlertTriangle, CheckCircle, Clock, CloudSun, DollarSign, FileText, Sparkles, RefreshCw, ArrowLeft } from 'lucide-react';

interface ProjectHealthProps {
  health: ProjectHealthMetrics;
  onBack: () => void;  // 👈 NEW
}

export const ProjectHealth: React.FC<ProjectHealthProps> = ({ health, onBack }) => {
  return (
    <div className="space-y-6">
      {/* Back Button */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition text-xs font-semibold text-slate-600 dark:text-slate-400"
        >
          <ArrowLeft size={16} />
          Back to Project Hub
        </button>
      </div>

      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 mb-1">
            <Activity className="w-4 h-4" />
            <span>Project Health Diagnostic Engine</span>
          </div>
          <h2 className="text-xl font-bold">{health.projectName}</h2>
          <p className="text-xs text-slate-300 mt-1">
            Real-time schedule, quality, safety, budget & documentation health diagnostic scorecard.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-emerald-950 border border-emerald-600 text-center">
            <span className="text-[10px] text-emerald-300 block font-mono">OVERALL HEALTH</span>
            <span className="text-2xl font-extrabold text-emerald-400">{health.overall}%</span>
          </div>
        </div>
      </div>

      {/* Main Health Metrics Breakdown Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {[
          { label: 'Schedule Performance', val: health.schedule, sub: 'S-Curve +2 Days Ahead', icon: <Clock className="w-4 h-4 text-blue-500" /> },
          { label: 'Quality & Testing', val: health.quality, sub: 'Concrete Cube 100% Pass', icon: <ShieldCheck className="w-4 h-4 text-emerald-500" /> },
          { label: 'Safety Index (HSE)', val: health.safety, sub: '0 Loss Time Incidents', icon: <CheckCircle className="w-4 h-4 text-teal-500" /> },
          { label: 'Budget Variance', val: health.budget, sub: 'Cost Control Target 85%', icon: <DollarSign className="w-4 h-4 text-amber-500" /> },
          { label: 'Documentation Compliance', val: health.documentation, sub: '76% Closeout', icon: <FileText className="w-4 h-4 text-purple-500" /> },
        ].map((m, i) => (
          <div key={i} className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{m.label}</span>
              {m.icon}
            </div>
            <div className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono">{m.val}%</div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
              <div className="bg-emerald-600 h-full rounded-full" style={{ width: `${m.val}%` }} />
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">{m.sub}</p>
          </div>
        ))}
      </div>

      {/* Risk Factors & AI Diagnostics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Risk Indicators */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            Risk & Bottleneck Indicators
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex justify-between items-center">
              <div>
                <span className="font-semibold block text-slate-900 dark:text-white">Open RFIs</span>
                <span className="text-[10px] text-slate-400">Awaiting consultant responses</span>
              </div>
              <span className="font-mono font-bold text-amber-500 text-sm">{health.openRFIs} Pending</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex justify-between items-center">
              <div>
                <span className="font-semibold block text-slate-900 dark:text-white">Outstanding Approvals</span>
                <span className="text-[10px] text-slate-400">Drawing revisions pending</span>
              </div>
              <span className="font-mono font-bold text-amber-500 text-sm">{health.outstandingApprovals} Pending</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex justify-between items-center">
              <div>
                <span className="font-semibold block text-slate-900 dark:text-white">Weather Delay Days</span>
                <span className="text-[10px] text-slate-400">Rain & wind site stoppages</span>
              </div>
              <span className="font-mono font-bold text-slate-900 dark:text-white text-sm">{health.weatherImpactsDays} Days</span>
            </div>
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-300" />
              AI Project Engineer Diagnostic Recommendations
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 font-mono">
              Proactive Risk Engine
            </span>
          </div>

          <div className="space-y-3 text-xs">
            {health.aiRecommendations.map((rec, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 flex items-start gap-3 leading-relaxed"
              >
                <div className="p-1 rounded bg-emerald-900 text-emerald-300 font-mono text-[10px] font-bold mt-0.5">
                  #{idx + 1}
                </div>
                <div className="text-slate-200">{rec}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};