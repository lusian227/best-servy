﻿// src/modules/records/services/RecordService.ts

import { EngineeringRecord, RecordCategory, Discipline, RecordStatus } from '../domain/EngineeringRecord';
import { RecordRepository } from '../../../repositories/RecordRepository';

const repo = new RecordRepository();

export interface CreateRecordInput {
  workspaceId: string;
  workspaceType: string;
  title: string;
  description?: string;
  recordType: string;
  category: RecordCategory;
  discipline: Discipline;
  createdBy: string;
  file?: File;
  metadata?: Record<string, any>;
}

export interface UpdateRecordInput {
  title?: string;
  description?: string;
  recordType?: string;
  category?: RecordCategory;
  discipline?: Discipline;
  status?: RecordStatus;
  updatedBy: string;
  metadata?: Record<string, any>;
}

export class RecordService {
  private idCounter = 1;

  async create(input: CreateRecordInput): Promise<EngineeringRecord> {
    const now = new Date();
    const record: EngineeringRecord = {
      id: 'rec-' + Date.now().toString(36) + '-' + String(this.idCounter++).padStart(4, '0'),
      workspaceId: input.workspaceId,
      parentType: 'workspace',
      parentId: input.workspaceId,
      title: input.title,
      description: input.description,
      recordNumber: this.generateRecordNumber(input.category),
      category: input.category,
      discipline: input.discipline,
      revision: 'REV0',
      version: 1,
      isLatest: true,
      status: 'draft' as RecordStatus,
      fileIds: [],
      metadata: input.metadata || {},
      relatedRecordIds: [],
      dependencies: [],
      tags: [],
      createdAt: now,
      updatedAt: now,
      createdBy: input.createdBy,
      updatedBy: input.createdBy,
    };

    const saved = await repo.save(record);
    console.log('📄 Record created:', saved.recordNumber);
    return saved;
  }

  async getAll(): Promise<EngineeringRecord[]> {
    return await repo.findAll();
  }

  async getByWorkspace(workspaceId: string): Promise<EngineeringRecord[]> {
    const records = await repo.findAll();
    return records.filter(r => r.workspaceId === workspaceId);
  }

  async getById(id: string): Promise<EngineeringRecord | undefined> {
    return await repo.findById(id);
  }

  async search(query: string): Promise<EngineeringRecord[]> {
    return await repo.search(query);
  }

  async update(id: string, input: UpdateRecordInput): Promise<EngineeringRecord | undefined> {
    const existing = await repo.findById(id);
    if (!existing) return undefined;

    const updated: EngineeringRecord = {
      ...existing,
      title: input.title ?? existing.title,
      description: input.description ?? existing.description,
      category: input.category ?? existing.category,
      discipline: input.discipline ?? existing.discipline,
      status: input.status ?? existing.status,
      metadata: input.metadata ? { ...existing.metadata, ...input.metadata } : existing.metadata,
      updatedAt: new Date(),
      updatedBy: input.updatedBy,
      version: existing.version + 1,
    };

    const saved = await repo.save(updated);
    console.log('✏️ Record updated:', saved.recordNumber);
    return saved;
  }

  async delete(id: string): Promise<boolean> {
    const result = await repo.delete(id);
    if (result) {
      console.log('🗑️ Record deleted:', id);
    }
    return result;
  }

  async upload(recordId: string, file: File, storageUrl: string): Promise<EngineeringRecord | undefined> {
    const record = await repo.findById(recordId);
    if (!record) return undefined;

    const updated: EngineeringRecord = {
      ...record,
      fileIds: [...record.fileIds, 'file-' + Date.now()],
      updatedAt: new Date(),
    };

    const saved = await repo.save(updated);
    console.log('📎 File uploaded to record:', saved.recordNumber);
    return saved;
  }

  private generateRecordNumber(category: RecordCategory): string {
    const prefix = category.slice(0, 3).toUpperCase();
    const num = String(this.idCounter).padStart(3, '0');
    this.idCounter++;
    return prefix + '-' + num;
  }
}
