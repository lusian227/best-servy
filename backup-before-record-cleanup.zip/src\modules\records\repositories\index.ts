﻿// src/modules/records/repositories/index.ts

export * from './IRepository';
export * from './RecordRepository';
export * from './FileRepository';
export * from './VersionRepository';
export * from './AnnotationRepository';
export * from './ApprovalRepository';
export * from './AuditRepository';
export * from './LinkRepository';
