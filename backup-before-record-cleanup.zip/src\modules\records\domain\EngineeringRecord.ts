﻿// src/modules/records/domain/EngineeringRecord.ts

export interface EngineeringRecord {
  id: string;
  
  // Workspace Association
  workspaceId: string;
  workspaceType: WorkspaceType;
  ownerId: string;
  
  // Identity
  title: string;
  description?: string;
  recordNumber: string;
  
  // Classification
  recordType: RecordType;  // What kind of engineering activity
  category: RecordCategory;
  discipline: Discipline;
  
  // Versioning
  revision: string;
  version: number;
  isLatest: boolean;
  
  // Status
  status: RecordStatus;
  
  // Files (multiple evidence)
  files: StoredFile[];
  primaryFileId?: string;
  
  // Rich Content
  notes?: string;
  annotations: Annotation[];
  comments: Comment[];
  
  // Relationships
  links: RecordLink[];
  dependencies: string[];
  
  // Tracking
  timeline: TimelineEvent[];
  audit: AuditTrail;
  
  // AI (placeholder - Phase 4)
  ai?: AIData;
  
  // Metadata (flexible)
  metadata: RecordMetadata;
  
  // Timestamps
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
}

export type RecordType =
  | 'site_activity'
  | 'drawing'
  | 'survey'
  | 'inspection'
  | 'material'
  | 'calculation'
  | 'research'
  | 'lecture_notes'
  | 'diary'
  | 'photo'
  | 'report'
  | 'specification'
  | 'contract'
  | 'rfi'
  | 'submittal'
  | 'model'
  | 'other';

export type WorkspaceType =
  | 'project'
  | 'personal'
  | 'student'
  | 'company'
  | 'team'
  | 'research'
  | 'laboratory';

export interface RecordMetadata {
  // Project context
  projectId?: string;
  projectName?: string;
  
  // Student context
  course?: string;
  semester?: string;
  topic?: string;
  
  // Engineering context
  structure?: string;
  material?: string;
  location?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
    elevation?: number;
  };
  
  // General
  tags: string[];
  customFields: Record<string, any>;
}

export interface TimelineEvent {
  id: string;
  type: 'created' | 'updated' | 'versioned' | 'commented' | 'annotated' | 'linked';
  description: string;
  performedBy: string;
  performedAt: Date;
}
