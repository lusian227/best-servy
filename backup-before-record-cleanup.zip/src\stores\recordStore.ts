﻿// src/stores/recordStore.ts

import { create } from 'zustand';
import { EngineeringRecord } from '../modules/records/domain/EngineeringRecord';
import { RecordRepository } from '../repositories';

const recordRepo = new RecordRepository();

interface RecordState {
  records: EngineeringRecord[];
  selectedRecord: EngineeringRecord | null;
  loading: boolean;
  error: string | null;
  loadRecords: () => void;
  setSelectedRecord: (record: EngineeringRecord | null) => void;
  addRecord: (record: EngineeringRecord) => void;
  updateRecord: (id: string, updates: Partial<EngineeringRecord>) => void;
  deleteRecord: (id: string) => void;
  getRecord: (id: string) => EngineeringRecord | undefined;
}

export const useRecordStore = create<RecordState>((set, get) => ({
  records: [],
  selectedRecord: null,
  loading: false,
  error: null,

  loadRecords: () => {
    set({ loading: true });
    try {
      const records = recordRepo.findAll();
      set({ records, loading: false, error: null });
    } catch (error) {
      set({ loading: false, error: 'Failed to load records' });
    }
  },

  setSelectedRecord: (record) => {
    set({ selectedRecord: record });
  },

  addRecord: (record) => {
    try {
      recordRepo.save(record);
      set({ records: recordRepo.findAll() });
    } catch (error) {
      set({ error: 'Failed to add record' });
    }
  },

  updateRecord: (id, updates) => {
    try {
      const record = get().records.find(r => r.id === id);
      if (record) {
        const updated = { ...record, ...updates };
        recordRepo.save(updated);
        set({ records: recordRepo.findAll() });
        const { selectedRecord } = get();
        if (selectedRecord?.id === id) {
          set({ selectedRecord: updated });
        }
      }
    } catch (error) {
      set({ error: 'Failed to update record' });
    }
  },

  deleteRecord: (id) => {
    try {
      recordRepo.delete(id);
      set({ records: recordRepo.findAll() });
      const { selectedRecord } = get();
      if (selectedRecord?.id === id) {
        set({ selectedRecord: null });
      }
    } catch (error) {
      set({ error: 'Failed to delete record' });
    }
  },

  getRecord: (id) => {
    return get().records.find(r => r.id === id);
  },
}));
