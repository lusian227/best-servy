export type World = 'workspace' | 'projects' | 'knowledge' | 'marketplace' | 'ai' | 'company';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  company: string;
  department: string;
  avatar: string;
}

export interface SingleSourceLink {
  id: string;
  type: 'drawing' | 'element' | 'photo' | 'inspection' | 'test' | 'site_instruction' | 'rfi' | 'decision' | 'lesson' | 'report';
  title: string;
  subtitle?: string;
  date: string;
  status?: string;
  author?: string;
}

export interface DecisionItem {
  id: string;
  decisionNumber: number;
  projectId: string;
  projectName: string;
  title: string;
  reason: string;
  requestedBy: string;
  reviewedBy: string;
  approvedBy: string;
  implemented: boolean;
  status: 'Approved' | 'Pending' | 'Rejected' | 'In Review';
  affectedDrawings: string[];
  relatedRFIs: string[];
  relatedPhotosCount: number;
  date: string;
  impactLevel: 'High' | 'Medium' | 'Low';
  costImpact?: string;
  scheduleImpact?: string;
}

export interface LessonItem {
  id: string;
  projectId: string;
  projectName: string;
  category: 'Structural' | 'Concrete' | 'Geotechnical' | 'Safety' | 'Procurement' | 'Site Management' | 'Design';
  title: string;
  whatWentWell: string;
  causesOfDelay: string;
  bestSuppliers: string;
  designChangesRepeated: string;
  recommendations: string;
  date: string;
  tags: string[];
}

export interface ProjectHealthMetrics {
  projectId: string;
  projectName: string;
  overall: number;
  schedule: number;
  quality: number;
  safety: number;
  budget: number;
  documentation: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  openRFIs: number;
  outstandingApprovals: number;
  weatherImpactsDays: number;
  materialShortageRisk: string;
  resourceUtilization: number;
  aiRecommendations: string[];
}

export interface ProjectItem {
  id: string;
  code: string;
  name: string;
  client: string;
  location: string;
  status: 'In Progress' | 'Design Phase' | 'Inspection' | 'Completed' | 'Delayed';
  progress: number;
  startDate: string;
  expectedCompletion: string;
  budget: number;
  spent: number;
  leadEngineer: string;
  health: ProjectHealthMetrics;
  recentDecisionsCount: number;
  openDefectsCount: number;
  image: string;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  category: 'Calculation' | 'Site Inspection' | 'Design Review' | 'Client Meeting' | 'SOP';
  date: string;
  tags: string[];
  hasAudio: boolean;
  hasSketch: boolean;
  linkedAssets: SingleSourceLink[];
}

export interface CalculationHistory {
  id: string;
  title: string;
  expression: string;
  result: string;
  type: 'General' | 'Beam Shear/Bending' | 'Concrete Takeoff' | 'Geotechnical' | 'Survey';
  date: string;
  notes?: string;
}

export interface TimelineEntry {
  id: string;
  date: string;
  time: string;
  type: 'Inspection' | 'Calculation' | 'Drawing Revision' | 'Decision Approved' | 'Site Diary' | 'Safety Audit';
  title: string;
  description: string;
  author: string;
  projectId?: string;
  projectName?: string;
  iconName: string;
  linkedAssetCount: number;
}

export interface DrawingItem {
  id: string;
  projectId: string;
  drawingNumber: string;
  title: string;
  discipline: 'Structural' | 'Architectural' | 'MEP' | 'Geotechnical' | 'Civil';
  revision: string;
  date: string;
  status: 'Approved for Construction' | 'Under Review' | 'Superseded' | 'Draft';
  fileUrl: string;
  annotationsCount: number;
  linkedAssets: SingleSourceLink[];
}

export interface SiteDiaryEntry {
  id: string;
  projectId: string;
  date: string;
  weather: {
    temp: string;
    condition: 'Sunny' | 'Rain' | 'Cloudy' | 'Windy';
    impact: 'None' | 'Minor Delay' | 'Site Stoppage';
  };
  workforceCount: number;
  keyActivities: string[];
  equipmentOnSite: { name: string; status: 'Operating' | 'Idle' | 'Maintenance' }[];
  deliveries: { material: string; quantity: string; supplier: string }[];
  photosCount: number;
  aiSummary: string;
  preparedBy: string;
}

export interface MarketplaceListing {
  id: string;
  title: string;
  category: 'Equipment Rentals' | 'Material Supply' | 'Skilled Worker' | 'Semi-Skilled Worker' | 'Unskilled Worker' | 'Contractor' | 'Property Sales/Rentals';
  provider: string;
  verified: boolean;
  rating: number;
  reviewsCount: number;
  location: string;
  priceRate: string;
  availability: string;
  description: string;
  contactEmail: string;
  contactPhone: string;
  specs: Record<string, string>;
  image: string;
}

export interface StandardDoc {
  id: string;
  code: string;
  title: string;
  category: 'Structural Design' | 'Concrete & Steel' | 'Geotechnical' | 'HSE & Safety' | 'Building Codes';
  publisher: 'Eurocode' | 'ACI' | 'BS' | 'ASTM' | 'ISO' | 'Company SOP';
  summary: string;
  clauseReference: string;
  fileSize: string;
}

export interface DigitalTwinNode {
  id: string;
  elementName: string;
  type: 'Column' | 'Beam' | 'Slab' | 'Foundation' | 'Retaining Wall';
  floor: string;
  status: 'Normal' | 'Warning' | 'Critical';
  stressRatio: number;
  deflectionMm: number;
  concreteGrade: string;
  lastTestedDate: string;
  sensorReading?: string;
  linkedInspectionId?: string;
}
