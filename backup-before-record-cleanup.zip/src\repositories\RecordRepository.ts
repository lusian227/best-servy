﻿// src/repositories/RecordRepository.ts

import { EngineeringRecord } from '../modules/records/domain/EngineeringRecord';
import { supabase } from '../lib/supabase';

export class RecordRepository {
  private useSupabase: boolean = import.meta.env.VITE_USE_SUPABASE === 'true';

  async findAll(): Promise<EngineeringRecord[]> {
    if (!this.useSupabase) {
      console.warn('⚠️ Supabase is disabled. Using in-memory data.');
      return [];
    }

    try {
      const { data, error } = await supabase
        .from('records')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Supabase error:', error);
        return [];
      }

      return data?.map(this.mapFromSupabase) || [];
    } catch (error) {
      console.error('Failed to fetch records:', error);
      return [];
    }
  }

  async findById(id: string): Promise<EngineeringRecord | undefined> {
    if (!this.useSupabase) return undefined;

    try {
      const { data, error } = await supabase
        .from('records')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        console.error('Supabase error:', error);
        return undefined;
      }

      return data ? this.mapFromSupabase(data) : undefined;
    } catch (error) {
      console.error('Failed to fetch record:', error);
      return undefined;
    }
  }

  async save(record: EngineeringRecord): Promise<EngineeringRecord> {
    if (!this.useSupabase) {
      console.warn('⚠️ Supabase is disabled. Record not saved.');
      return record;
    }

    try {
      const supabaseRecord = this.mapToSupabase(record);
      console.log('📤 Saving to Supabase:', supabaseRecord);

      const { data, error } = await supabase
        .from('records')
        .upsert(supabaseRecord)
        .select()
        .single();

      if (error) {
        console.error('❌ Supabase error details:', error);
        return record;
      }

      console.log('✅ Record saved successfully:', data);
      return data ? this.mapFromSupabase(data) : record;
    } catch (error) {
      console.error('❌ Failed to save record:', error);
      return record;
    }
  }

  async delete(id: string): Promise<boolean> {
    if (!this.useSupabase) {
      console.warn('⚠️ Supabase is disabled. Record not deleted.');
      return false;
    }

    try {
      const { error } = await supabase
        .from('records')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Supabase error:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Failed to delete record:', error);
      return false;
    }
  }

  async search(query: string): Promise<EngineeringRecord[]> {
    if (!this.useSupabase) {
      console.warn('⚠️ Supabase is disabled. Search not available.');
      return [];
    }

    if (!query || query.trim() === '') {
      return await this.findAll();
    }

    try {
      const searchTerm = query.trim();
      const { data, error } = await supabase
        .from('records')
        .select('*')
        .or(
          'title.ilike.%' + searchTerm + '%,' +
          'record_number.ilike.%' + searchTerm + '%,' +
          'description.ilike.%' + searchTerm + '%'
        )
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Supabase error:', error);
        return [];
      }

      return data?.map(this.mapFromSupabase) || [];
    } catch (error) {
      console.error('Failed to search records:', error);
      return [];
    }
  }

  private mapFromSupabase(data: any): EngineeringRecord {
    return {
      id: data.id,
      projectId: data.project_id,
      recordNumber: data.record_number,
      title: data.title,
      description: data.description,
      category: data.category,
      discipline: data.discipline,
      revision: data.revision || 'REV0',
      version: data.version || 1,
      status: data.status || 'draft',
      fileId: data.file_id,
      fileName: data.file_name,
      fileSize: data.file_size,
      mimeType: data.mime_type,
      storageUrl: data.storage_url,
      thumbnailUrl: data.thumbnail_url,
      metadata: data.metadata || { customFields: {} },
      createdAt: new Date(data.created_at),
      updatedAt: new Date(data.updated_at),
      createdBy: data.created_by,
      updatedBy: data.updated_by,
    };
  }

  private mapToSupabase(record: EngineeringRecord): any {
    return {
      id: record.id,
      project_id: record.projectId,
      record_number: record.recordNumber,
      title: record.title,
      description: record.description,
      category: record.category,
      discipline: record.discipline,
      revision: record.revision,
      version: record.version,
      status: record.status,
      file_id: record.fileId,
      file_name: record.fileName,
      file_size: record.fileSize,
      mime_type: record.mimeType,
      storage_url: record.storageUrl,
      thumbnail_url: record.thumbnailUrl,
      metadata: record.metadata,
      created_by: record.createdBy,
      updated_by: record.updatedBy,
      created_at: record.createdAt,
      updated_at: record.updatedAt,
    };
  }
}