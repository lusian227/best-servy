﻿// src/modules/records/repositories/RecordRepository.ts

import { EngineeringRecord, RecordStatus, RecordCategory, Discipline } from '../domain/EngineeringRecord';
import { IRepository } from './IRepository';

export interface RecordQuery {
  projectId?: string;
  category?: RecordCategory;
  status?: RecordStatus;
  discipline?: Discipline;
  searchTerm?: string;
  limit?: number;
  offset?: number;
}

export interface IRecordRepository extends IRepository<EngineeringRecord, string> {
  findByProject(projectId: string): Promise<EngineeringRecord[]>;
  findByCategory(category: RecordCategory): Promise<EngineeringRecord[]>;
  findByStatus(status: RecordStatus): Promise<EngineeringRecord[]>;
  findByRecordNumber(recordNumber: string): Promise<EngineeringRecord | null>;
  search(query: RecordQuery): Promise<EngineeringRecord[]>;
  getLatestVersion(recordId: string): Promise<EngineeringRecord | null>;
}

/**
 * In-memory implementation of RecordRepository
 * Replace with PostgreSQL/MongoDB in production
 */
export class RecordRepository implements IRecordRepository {
  private records: Map<string, EngineeringRecord> = new Map();
  private nextId: number = 1;

  /**
   * Save a new record
   */
  async save(record: EngineeringRecord): Promise<EngineeringRecord> {
    if (!record.id) {
      record.id = this.generateId();
    }
    this.records.set(record.id, record);
    return record;
  }

  /**
   * Find a record by ID
   */
  async findById(id: string): Promise<EngineeringRecord | null> {
    return this.records.get(id) || null;
  }

  /**
   * Find a record by record number (e.g., "DRA-ABC123")
   */
  async findByRecordNumber(recordNumber: string): Promise<EngineeringRecord | null> {
    for (const record of this.records.values()) {
      if (record.recordNumber === recordNumber) {
        return record;
      }
    }
    return null;
  }

  /**
   * Find records by project ID
   */
  async findByProject(projectId: string): Promise<EngineeringRecord[]> {
    const results: EngineeringRecord[] = [];
    for (const record of this.records.values()) {
      if (record.projectId === projectId) {
        results.push(record);
      }
    }
    return results;
  }

  /**
   * Find records by category
   */
  async findByCategory(category: RecordCategory): Promise<EngineeringRecord[]> {
    const results: EngineeringRecord[] = [];
    for (const record of this.records.values()) {
      if (record.category === category) {
        results.push(record);
      }
    }
    return results;
  }

  /**
   * Find records by status
   */
  async findByStatus(status: RecordStatus): Promise<EngineeringRecord[]> {
    const results: EngineeringRecord[] = [];
    for (const record of this.records.values()) {
      if (record.status === status) {
        results.push(record);
      }
    }
    return results;
  }

  /**
   * Get all records
   */
  async findAll(): Promise<EngineeringRecord[]> {
    return Array.from(this.records.values());
  }

  /**
   * Search records with filters
   */
  async search(query: RecordQuery): Promise<EngineeringRecord[]> {
    let results = Array.from(this.records.values());

    // Apply filters
    if (query.projectId) {
      results = results.filter(r => r.projectId === query.projectId);
    }
    if (query.category) {
      results = results.filter(r => r.category === query.category);
    }
    if (query.status) {
      results = results.filter(r => r.status === query.status);
    }
    if (query.discipline) {
      results = results.filter(r => r.discipline === query.discipline);
    }
    if (query.searchTerm) {
      const term = query.searchTerm.toLowerCase();
      results = results.filter(r =>
        r.title.toLowerCase().includes(term) ||
        r.recordNumber.toLowerCase().includes(term) ||
        r.description?.toLowerCase().includes(term)
      );
    }

    // Apply pagination
    if (query.limit !== undefined) {
      const start = query.offset || 0;
      results = results.slice(start, start + query.limit);
    }

    return results;
  }

  /**
   * Update a record
   */
  async update(id: string, entity: Partial<EngineeringRecord>): Promise<EngineeringRecord> {
    const existing = await this.findById(id);
    if (!existing) {
      throw new Error(Record with id  not found);
    }

    const updated = {
      ...existing,
      ...entity,
      updatedAt: new Date()
    };

    this.records.set(id, updated);
    return updated;
  }

  /**
   * Delete a record (soft delete)
   */
  async delete(id: string): Promise<void> {
    const existing = await this.findById(id);
    if (existing) {
      existing.status = RecordStatus.ARCHIVED;
      existing.updatedAt = new Date();
      this.records.set(id, existing);
    }
  }

  /**
   * Hard delete a record (permanent)
   */
  async hardDelete(id: string): Promise<void> {
    this.records.delete(id);
  }

  /**
   * Check if a record exists
   */
  async exists(id: string): Promise<boolean> {
    return this.records.has(id);
  }

  /**
   * Count total records
   */
  async count(): Promise<number> {
    return this.records.size;
  }

  /**
   * Get the latest version of a record
   */
  async getLatestVersion(recordId: string): Promise<EngineeringRecord | null> {
    const record = await this.findById(recordId);
    if (!record) return null;
    return record.isLatest ? record : null;
  }

  /**
   * Clear all records (for testing)
   */
  async clear(): Promise<void> {
    this.records.clear();
  }

  /**
   * Generate a unique ID
   */
  private generateId(): string {
    return crypto.randomUUID();
  }
}
